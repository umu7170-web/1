<?php
session_start();

if (!isset($_SESSION["wins"])) {
    $_SESSION["wins"] = 0;
    $_SESSION["losses"] = 0;
    $_SESSION["draws"] = 0;
}

$choices = [
    "rock" => "Камень ✊",
    "paper" => "Бумага ✋",
    "scissors" => "Ножницы ✌️"
];

$computerChoice = null;
$result = null;
$playerChoice = null;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = $_POST["action"] ?? "";

    if ($action === "reset") {
        $_SESSION["wins"] = 0;
        $_SESSION["losses"] = 0;
        $_SESSION["draws"] = 0;
    } elseif ($action === "play") {
        $playerChoice = $_POST["choice"] ?? "";

        if (array_key_exists($playerChoice, $choices)) {
            $computerChoice = array_rand($choices);

            if ($playerChoice === $computerChoice) {
                $result = "draw";
                $_SESSION["draws"]++;
            } elseif (
                ($playerChoice === "rock" && $computerChoice === "scissors") ||
                ($playerChoice === "paper" && $computerChoice === "rock") ||
                ($playerChoice === "scissors" && $computerChoice === "paper")
            ) {
                $result = "win";
                $_SESSION["wins"]++;
            } else {
                $result = "loss";
                $_SESSION["losses"]++;
            }
        }
    }
}

$resultText = [
    "win" => "Ты победил!",
    "loss" => "Компьютер победил!",
    "draw" => "Ничья!"
];

$resultClass = [
    "win" => "win",
    "loss" => "loss",
    "draw" => "draw"
];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Камень, ножницы, бумага</title>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            min-height: 100vh;
            display: grid;
            place-items: center;
            padding: 24px;
            font-family: Arial, Helvetica, sans-serif;
            color: #f5f7ff;
            background:
                radial-gradient(circle at 15% 15%, #26366b 0, transparent 32%),
                radial-gradient(circle at 85% 85%, #3c235e 0, transparent 30%),
                #101426;
        }
        .game {
            width: 100%;
            max-width: 680px;
            padding: 34px;
            border: 1px solid rgba(255,255,255,.12);
            border-radius: 28px;
            background: rgba(24, 30, 54, .92);
            box-shadow: 0 24px 80px rgba(0,0,0,.35);
            text-align: center;
        }
        .tag {
            display: inline-block;
            padding: 7px 12px;
            border-radius: 999px;
            color: #c5ccff;
            background: rgba(126, 141, 255, .13);
            font-size: 12px;
            font-weight: bold;
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }
        h1 { margin: 18px 0 10px; font-size: clamp(28px, 5vw, 40px); }
        .subtitle { margin: 0 auto 28px; color: #aeb7d4; line-height: 1.6; }
        .choices {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
            margin: 24px 0;
        }
        .choice {
            min-height: 120px;
            padding: 18px 8px;
            border: 1px solid rgba(255,255,255,.13);
            border-radius: 18px;
            color: #f5f7ff;
            background: #242c4c;
            cursor: pointer;
            transition: transform .18s, background .18s, border-color .18s;
        }
        .choice:hover {
            transform: translateY(-4px);
            background: #303b65;
            border-color: #8794ff;
        }
        .emoji { display: block; font-size: 38px; margin-bottom: 10px; }
        .choice span:last-child { font-weight: bold; }
        .result {
            margin-top: 22px;
            padding: 20px;
            border-radius: 18px;
            background: rgba(255,255,255,.05);
            border: 1px solid rgba(255,255,255,.1);
        }
        .result h2 { margin: 0 0 14px; font-size: 24px; }
        .result.win h2 { color: #73e6ac; }
        .result.loss h2 { color: #ff8d9a; }
        .result.draw h2 { color: #ffd479; }
        .versus { display: flex; justify-content: center; gap: 16px; flex-wrap: wrap; color: #dce2ff; }
        .versus span { display: inline-block; padding: 10px 14px; border-radius: 12px; background: rgba(255,255,255,.06); }
        .stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-top: 24px;
        }
        .stat { padding: 16px 8px; border-radius: 15px; background: rgba(255,255,255,.045); }
        .number { display: block; margin-bottom: 5px; font-size: 26px; font-weight: bold; }
        .stat-label { color: #aeb7d4; font-size: 13px; }
        .reset {
            margin-top: 22px;
            padding: 11px 18px;
            border: 1px solid rgba(255,255,255,.18);
            border-radius: 12px;
            color: #dce2ff;
            background: transparent;
            cursor: pointer;
        }
        .reset:hover { background: rgba(255,255,255,.08); }
        .hint { margin-top: 20px; color: #818bad; font-size: 12px; }
        @media (max-width: 480px) {
            .game { padding: 22px 16px; }
            .choices { gap: 8px; }
            .choice { min-height: 105px; font-size: 13px; }
            .emoji { font-size: 32px; }
        }
    </style>
</head>
<body>
    <main class="game">
        <span class="tag">Мини-игра на PHP</span>
        <h1>Камень, ножницы, бумага</h1>
        <p class="subtitle">Сделай свой выбор и попробуй победить компьютер.</p>

        <form method="post" class="choices">
            <input type="hidden" name="action" value="play">
            <button class="choice" type="submit" name="choice" value="rock">
                <span class="emoji">✊</span>
                <span>Камень</span>
            </button>
            <button class="choice" type="submit" name="choice" value="paper">
                <span class="emoji">✋</span>
                <span>Бумага</span>
            </button>
            <button class="choice" type="submit" name="choice" value="scissors">
                <span class="emoji">✌️</span>
                <span>Ножницы</span>
            </button>
        </form>

        <?php if ($result !== null && $playerChoice !== null && $computerChoice !== null): ?>
            <section class="result <?= htmlspecialchars($resultClass[$result], ENT_QUOTES, 'UTF-8') ?>">
                <h2><?= htmlspecialchars($resultText[$result], ENT_QUOTES, 'UTF-8') ?></h2>
                <div class="versus">
                    <span>Ты: <?= htmlspecialchars($choices[$playerChoice], ENT_QUOTES, 'UTF-8') ?></span>
                    <span>Компьютер: <?= htmlspecialchars($choices[$computerChoice], ENT_QUOTES, 'UTF-8') ?></span>
                </div>
            </section>
        <?php endif; ?>

        <section class="stats" aria-label="Счёт игры">
            <div class="stat">
                <span class="number"><?= (int) $_SESSION["wins"] ?></span>
                <span class="stat-label">Победы</span>
            </div>
            <div class="stat">
                <span class="number"><?= (int) $_SESSION["draws"] ?></span>
                <span class="stat-label">Ничьи</span>
            </div>
            <div class="stat">
                <span class="number"><?= (int) $_SESSION["losses"] ?></span>
                <span class="stat-label">Поражения</span>
            </div>
        </section>

        <form method="post">
            <input type="hidden" name="action" value="reset">
            <button class="reset" type="submit">Сбросить счёт ↻</button>
        </form>

        <p class="hint">Создано на PHP · HTML · CSS</p>
    </main>
</body>
</html>
